

function alertValues()
{
alert("Customer information: " + "\n     " + fullname.value + "\n     " + tel.value + "\n     " + email.value);  
}


